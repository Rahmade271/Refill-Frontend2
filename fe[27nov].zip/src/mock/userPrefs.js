//Menyimpan data preferensi pengguna tiruan (theme, fontSize) untuk menguji styling dinamis.

export const MOCK_USER_PREFS = {
    layoutWidth: 'standard', 
    fontStyle: 'default',
    theme: 'dark', 
    fontSize: 'medium',
};